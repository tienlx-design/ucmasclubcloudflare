export interface Question {
  globalNum: number;
  operands: number[];
  correct: number;
}

export interface ExamSet {
  id: string;
  name: string;
  level: number;
  questionCount: number;
  questions?: Question[];
  createdAt: Date;
}

export interface ExamConfig {
  totalQuestions: number;
  timeLimit: number; // in seconds
  level: string;
}

export interface StudentInfo {
  name: string;
  code?: string; // Student code (optional)
  level: number;
  examSource?: 'auto' | 'preset';
  examSetId?: string; // Optional: use preset exam
  readingSpeed?: number; // For listening practice (0.5s - 3s)
  displaySpeed?: number; // For flash practice (0.25s - 3s)
  selectedVoice?: string; // For listening practice - voice URI or 'google-translate'
  speechLanguage?: 'vi' | 'en' | 'ru' | 'ms'; // Language for speech
}

export const SPEECH_LANGUAGES = [
  { value: 'vi', label: '🇻🇳 Tiếng Việt', code: 'vi-VN' },
  { value: 'en', label: '🇬🇧 Tiếng Anh', code: 'en-US' },
  { value: 'ru', label: '🇷🇺 Tiếng Nga', code: 'ru-RU' },
  { value: 'ms', label: '🇲🇾 Tiếng Malaysia', code: 'ms-MY' },
] as const;

export interface ExamResult {
  studentInfo: StudentInfo;
  totalQuestions: number;
  totalAnswered: number;
  correctCount: number;
  timeUsed: number; // in seconds
  answers: (number | null)[];
  createdAt: Date;
  practiceType?: 'visual' | 'listening' | 'flash';
}

export type ExamScreen = 'welcome' | 'countdown' | 'exam' | 'result';

export const LEVELS = [
  { value: 1, label: 'Cấp 1' },
  { value: 2, label: 'Cấp 2' },
  { value: 3, label: 'Cấp 3' },
  { value: 4, label: 'Cấp 4' },
  { value: 5, label: 'Cấp 5' },
  { value: 6, label: 'Cấp 6' },
  { value: 7, label: 'Cấp 7' },
  { value: 8, label: 'Cấp 8' },
  { value: 9, label: 'Cấp 9' },
  { value: 10, label: 'Cấp 10' },
] as const;

export const LEVEL_CONFIG: Record<number, number[]> = {
  1: [3, 3, 3, 4, 4, 4, 5, 5],
  2: [3, 4, 4, 5, 5, 5, 6, 6],
  3: [4, 4, 5, 5, 5, 6, 6, 6],
  4: [4, 5, 5, 5, 6, 6, 6, 7],
  5: [5, 5, 5, 6, 6, 6, 7, 7],
  6: [5, 5, 6, 6, 6, 7, 7, 7],
  7: [5, 6, 6, 6, 7, 7, 7, 8],
  8: [6, 6, 6, 7, 7, 7, 8, 8],
  9: [6, 6, 7, 7, 7, 8, 8, 8],
  10: [6, 7, 7, 7, 8, 8, 8, 9],
};
