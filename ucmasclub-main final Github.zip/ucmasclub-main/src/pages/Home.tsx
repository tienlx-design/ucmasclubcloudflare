import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Eye, Headphones, Sparkles, Zap } from 'lucide-react';
import logo from '@/assets/logo_UCMAS.png';
import { Helmet } from 'react-helmet-async';

const practiceTypes = [
  {
    id: 'visual',
    title: 'Nhìn Tính',
    description: '200 câu hỏi • 8 phút',
    icon: Eye,
    path: '/nhin-tinh',
    gradient: 'gradient-primary',
    shadowGlow: 'shadow-glow-primary',
    iconColor: 'text-primary-foreground',
  },
  {
    id: 'listening',
    title: 'Nghe Tính',
    description: '30 câu hỏi • Nghe đọc số',
    icon: Headphones,
    path: '/nghe-tinh',
    gradient: 'gradient-secondary',
    shadowGlow: 'shadow-glow-secondary',
    iconColor: 'text-primary-foreground',
  },
  {
    id: 'flash',
    title: 'Flash',
    description: '30 câu hỏi • Thẻ số nhanh',
    icon: Zap,
    path: '/flash',
    gradient: 'bg-green-500',
    shadowGlow: 'shadow-glow-accent',
    iconColor: 'text-white',
  },
];

export default function Home() {
  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <title>UCMAS Club - Luyện Tập Toán Tư Duy</title>
        <meta name="description" content="Webapp luyện tập UCMAS dành cho học sinh từ 6-12 tuổi. Nhìn tính và Nghe tính." />
      </Helmet>

      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-background via-background to-muted">
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-24 h-24 rounded-full bg-primary/10 animate-float" />
        <div className="absolute bottom-20 right-10 w-36 h-36 rounded-full bg-secondary/10 animate-float stagger-2" />
        <div className="absolute top-1/3 right-20 w-20 h-20 rounded-full bg-accent/20 animate-float stagger-3" />
        <div className="absolute bottom-1/3 left-20 w-16 h-16 rounded-full bg-success/15 animate-float stagger-4" />

        <div className="w-full max-w-2xl animate-slide-up">
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <img 
              src={logo} 
              alt="UCMAS Logo" 
              className="h-24 w-auto animate-float"
            />
          </div>

          {/* Header */}
          <div className="text-center mb-10">
            <h1 className="text-4xl md:text-5xl font-extrabold text-foreground mb-3">
              Chào mừng đến với
            </h1>
            <div className="flex items-center justify-center gap-2 mb-4">
              <Sparkles className="w-8 h-8 text-accent" />
              <span className="text-4xl md:text-5xl font-black text-white px-4 py-2 rounded-xl gradient-hero">
                UCMAS Club
              </span>
              <Sparkles className="w-8 h-8 text-accent" />
            </div>
            <p className="text-lg text-muted-foreground">
              Chọn bài luyện tập để bắt đầu
            </p>
          </div>

          {/* Practice Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {practiceTypes.map((practice, index) => (
              <button
                key={practice.id}
                onClick={() => navigate(practice.path)}
                className={`
                  group relative bg-card rounded-2xl shadow-card p-8 border border-border
                  hover:scale-105 transition-all duration-300 text-left
                  hover:border-primary/50 animate-slide-up
                `}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Icon */}
                <div className={`
                  w-16 h-16 rounded-2xl ${practice.gradient} 
                  flex items-center justify-center mb-5
                  group-hover:${practice.shadowGlow} transition-all duration-300
                `}>
                  <practice.icon className={`w-8 h-8 ${practice.iconColor}`} />
                </div>

                {/* Content */}
                <h2 className="text-2xl font-extrabold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {practice.title}
                </h2>
                <p className="text-muted-foreground">
                  {practice.description}
                </p>

                {/* Arrow */}
                <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg className="w-6 h-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </div>
              </button>
            ))}
          </div>

          {/* Footer */}
          <p className="text-center text-muted-foreground text-sm mt-10">
            UCMAS Club - Education With A Difference
          </p>
        </div>
      </div>
    </>
  );
}
