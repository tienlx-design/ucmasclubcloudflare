import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FlashWelcomeScreen } from '@/components/flash/FlashWelcomeScreen';
import { CountdownScreen } from '@/components/CountdownScreen';
import { FlashExamScreen } from '@/components/flash/FlashExamScreen';
import { ResultScreen } from '@/components/ResultScreen';
import { ExamScreen as ExamScreenType, StudentInfo, ExamResult, Question } from '@/types/exam';
import { generateExam } from '@/utils/examGenerator';
import { Helmet } from 'react-helmet-async';

const FLASH_QUESTIONS = 30;

export default function FlashPractice() {
  const navigate = useNavigate();
  const [screen, setScreen] = useState<ExamScreenType>('welcome');
  const [studentInfo, setStudentInfo] = useState<StudentInfo | null>(null);
  const [examData, setExamData] = useState<Question[]>([]);
  const [result, setResult] = useState<ExamResult | null>(null);

  const handleStart = useCallback((info: StudentInfo) => {
    setStudentInfo(info);
    setScreen('countdown');
  }, []);

  const handleCountdownComplete = useCallback(() => {
    if (studentInfo) {
      // Generate only 30 questions for flash practice
      const allExam = generateExam(studentInfo.level);
      const exam = allExam.slice(0, FLASH_QUESTIONS).map((q, idx) => ({
        ...q,
        globalNum: idx + 1,
      }));
      setExamData(exam);
      setScreen('exam');
    }
  }, [studentInfo]);

  const handleFinish = useCallback((examResult: ExamResult) => {
    setResult({
      ...examResult,
      practiceType: 'flash',
    });
    setScreen('result');
  }, []);

  const handleRestart = useCallback(() => {
    setScreen('welcome');
    setStudentInfo(null);
    setExamData([]);
    setResult(null);
  }, []);

  const handleBackToHome = useCallback(() => {
    navigate('/');
  }, [navigate]);

  return (
    <>
      <Helmet>
        <title>Luyện Tập Flash - UCMAS Club</title>
        <meta name="description" content="Luyện tập Flash UCMAS - 30 câu hỏi hiển thị nhanh." />
      </Helmet>
      
      {screen === 'welcome' && (
        <FlashWelcomeScreen onStart={handleStart} onBack={handleBackToHome} />
      )}
      
      {screen === 'countdown' && (
        <CountdownScreen onComplete={handleCountdownComplete} />
      )}
      
      {screen === 'exam' && studentInfo && (
        <FlashExamScreen 
          studentInfo={studentInfo}
          examData={examData}
          onFinish={handleFinish}
        />
      )}
      
      {screen === 'result' && result && examData.length > 0 && (
        <ResultScreen 
          result={result} 
          examData={examData}
          onRestart={handleRestart} 
          onBackToHome={handleBackToHome}
        />
      )}
    </>
  );
}
