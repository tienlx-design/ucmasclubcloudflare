import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { WelcomeScreen } from '@/components/WelcomeScreen';
import { CountdownScreen } from '@/components/CountdownScreen';
import { ExamScreen } from '@/components/ExamScreen';
import { ResultScreen } from '@/components/ResultScreen';
import { ExamScreen as ExamScreenType, StudentInfo, ExamResult, Question } from '@/types/exam';
import { generateExam } from '@/utils/examGenerator';
import { Helmet } from 'react-helmet-async';

export default function VisualPractice() {
  const navigate = useNavigate();
  const [screen, setScreen] = useState<ExamScreenType>('welcome');
  const [studentInfo, setStudentInfo] = useState<StudentInfo | null>(null);
  const [examData, setExamData] = useState<Question[]>([]);
  const [result, setResult] = useState<ExamResult | null>(null);

  const handleStart = useCallback((info: StudentInfo) => {
    setStudentInfo(info);
    setScreen('countdown');
  }, []);

  const handleCountdownComplete = useCallback(() => {
    if (studentInfo) {
      const exam = generateExam(studentInfo.level);
      setExamData(exam);
      setScreen('exam');
    }
  }, [studentInfo]);

  const handleFinish = useCallback((examResult: ExamResult) => {
    setResult(examResult);
    setScreen('result');
  }, []);

  const handleRestart = useCallback(() => {
    setScreen('welcome');
    setStudentInfo(null);
    setExamData([]);
    setResult(null);
  }, []);

  const handleBackToHome = useCallback(() => {
    navigate('/');
  }, [navigate]);

  return (
    <>
      <Helmet>
        <title>Luyện Tập Nhìn Tính - UCMAS Club</title>
        <meta name="description" content="Luyện tập nhìn tính UCMAS - 200 câu hỏi trong 8 phút." />
      </Helmet>
      
      {screen === 'welcome' && (
        <WelcomeScreen onStart={handleStart} onBack={handleBackToHome} />
      )}
      
      {screen === 'countdown' && (
        <CountdownScreen onComplete={handleCountdownComplete} />
      )}
      
      {screen === 'exam' && studentInfo && (
        <ExamScreen 
          studentInfo={studentInfo}
          examData={examData}
          onFinish={handleFinish}
        />
      )}
      
      {screen === 'result' && result && examData.length > 0 && (
        <ResultScreen 
          result={result} 
          examData={examData}
          onRestart={handleRestart} 
          onBackToHome={handleBackToHome}
        />
      )}
    </>
  );
}
