import { Question, LEVEL_CONFIG } from '@/types/exam';

export function generateExam(level: number): Question[] {
  const groups = LEVEL_CONFIG[level] || [5, 5, 4, 5, 3, 3, 3, 7];
  const exam: Question[] = [];
  let globalNum = 1;

  groups.forEach((operandsCount) => {
    for (let col = 0; col < 25; col++) {
      const ops: number[] = [];
      let prevWasNegative = false;
      
      for (let r = 0; r < operandsCount; r++) {
        const num = Math.floor(Math.random() * 9) + 1; // 1..9
        if (r === 0) {
          ops.push(num); // First number is always positive
          prevWasNegative = false;
        } else {
          // Prevent consecutive subtractions
          if (prevWasNegative) {
            ops.push(num); // Must be positive after a negative
            prevWasNegative = false;
          } else {
            const isNegative = Math.random() < 0.5;
            ops.push(isNegative ? -num : num);
            prevWasNegative = isNegative;
          }
        }
      }
      
      const ans = ops.reduce((a, b) => a + b, 0);
      
      exam.push({
        globalNum: globalNum++,
        operands: ops,
        correct: ans,
      });
    }
  });

  return exam;
}

export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatTimeVerbose(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  if (mins > 0) {
    return `${mins} phút ${secs} giây`;
  }
  return `${secs} giây`;
}
