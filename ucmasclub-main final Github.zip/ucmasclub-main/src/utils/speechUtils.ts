import { supabase } from '@/integrations/supabase/client';

// Number words for different languages
const numberWords: Record<string, Record<number, string>> = {
  vi: {
    0: 'không', 1: 'một', 2: 'hai', 3: 'ba', 4: 'bốn',
    5: 'năm', 6: 'sáu', 7: 'bảy', 8: 'tám', 9: 'chín',
  },
  en: {
    0: 'zero', 1: 'one', 2: 'two', 3: 'three', 4: 'four',
    5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine',
  },
  ru: {
    0: 'ноль', 1: 'один', 2: 'два', 3: 'три', 4: 'четыре',
    5: 'пять', 6: 'шесть', 7: 'семь', 8: 'восемь', 9: 'девять',
  },
  ms: {
    0: 'kosong', 1: 'satu', 2: 'dua', 3: 'tiga', 4: 'empat',
    5: 'lima', 6: 'enam', 7: 'tujuh', 8: 'lapan', 9: 'sembilan',
  },
};

// Operator words for different languages
const operatorWords: Record<string, { plus: string; minus: string; ready: string; equals: string }> = {
  vi: { plus: 'cộng', minus: 'trừ', ready: 'Chuẩn bị', equals: 'Bằng' },
  en: { plus: 'plus', minus: 'minus', ready: 'Ready', equals: 'Equals' },
  ru: { plus: 'плюс', minus: 'минус', ready: 'Приготовьтесь', equals: 'Равно' },
  ms: { plus: 'tambah', minus: 'tolak', ready: 'Sedia', equals: 'Sama dengan' },
};

// Convert a number to words in specified language
function numberToWords(num: number, lang: string = 'vi'): string {
  const words = numberWords[lang] || numberWords.vi;
  
  if (num >= 0 && num <= 9) {
    return words[num];
  }
  
  const absNum = Math.abs(num);
  
  if (absNum >= 10 && absNum <= 99) {
    const tens = Math.floor(absNum / 10);
    const units = absNum % 10;
    
    if (lang === 'vi') {
      let result = tens === 1 ? 'mười' : words[tens] + ' mươi';
      if (units > 0) {
        if (units === 1 && tens > 1) result += ' mốt';
        else if (units === 5 && tens > 1) result += ' lăm';
        else result += ' ' + words[units];
      }
      return result;
    } else if (lang === 'en') {
      const tensWords: Record<number, string> = {
        2: 'twenty', 3: 'thirty', 4: 'forty', 5: 'fifty',
        6: 'sixty', 7: 'seventy', 8: 'eighty', 9: 'ninety',
      };
      const teensWords: Record<number, string> = {
        10: 'ten', 11: 'eleven', 12: 'twelve', 13: 'thirteen', 14: 'fourteen',
        15: 'fifteen', 16: 'sixteen', 17: 'seventeen', 18: 'eighteen', 19: 'nineteen',
      };
      if (absNum < 20) return teensWords[absNum];
      return tensWords[tens] + (units > 0 ? ' ' + words[units] : '');
    } else if (lang === 'ru') {
      const tensWords: Record<number, string> = {
        1: 'десять', 2: 'двадцать', 3: 'тридцать', 4: 'сорок', 5: 'пятьдесят',
        6: 'шестьдесят', 7: 'семьдесят', 8: 'восемьдесят', 9: 'девяносто',
      };
      if (tens === 1) {
        const teensWords: Record<number, string> = {
          11: 'одиннадцать', 12: 'двенадцать', 13: 'тринадцать', 14: 'четырнадцать',
          15: 'пятнадцать', 16: 'шестнадцать', 17: 'семнадцать', 18: 'восемнадцать', 19: 'девятнадцать',
        };
        return units === 0 ? tensWords[1] : teensWords[absNum];
      }
      return tensWords[tens] + (units > 0 ? ' ' + words[units] : '');
    } else if (lang === 'ms') {
      if (tens === 1) return 'se' + (units === 0 ? 'puluh' : 'belas');
      return words[tens] + ' puluh' + (units > 0 ? ' ' + words[units] : '');
    }
  }
  
  // For larger numbers (100-999) - simplified
  if (absNum >= 100 && absNum <= 999) {
    const hundreds = Math.floor(absNum / 100);
    const remainder = absNum % 100;
    
    if (lang === 'vi') {
      let result = words[hundreds] + ' trăm';
      if (remainder > 0) {
        if (remainder < 10) result += ' linh ' + words[remainder];
        else result += ' ' + numberToWords(remainder, lang);
      }
      return result;
    } else if (lang === 'en') {
      return words[hundreds] + ' hundred' + (remainder > 0 ? ' ' + numberToWords(remainder, lang) : '');
    } else if (lang === 'ru') {
      const hundredsWords: Record<number, string> = {
        1: 'сто', 2: 'двести', 3: 'триста', 4: 'четыреста', 5: 'пятьсот',
        6: 'шестьсот', 7: 'семьсот', 8: 'восемьсот', 9: 'девятьсот',
      };
      return hundredsWords[hundreds] + (remainder > 0 ? ' ' + numberToWords(remainder, lang) : '');
    } else if (lang === 'ms') {
      const hundredWord = hundreds === 1 ? 'seratus' : words[hundreds] + ' ratus';
      return hundredWord + (remainder > 0 ? ' ' + numberToWords(remainder, lang) : '');
    }
  }
  
  return num.toString();
}

/**
 * Convert operands array to speech text for listening practice
 * Rules:
 * - Always start with "Ready" and end with "Equals" (in respective language)
 * - Consecutive numbers with same sign: only say the sign once
 * - Example: 5, -1, -2, +5, +4 => "Chuẩn bị. Năm, trừ một, hai, cộng năm, bốn. Bằng"
 */
export function operandsToSpeech(operands: number[], lang: string = 'vi'): string {
  if (operands.length === 0) return '';
  
  const ops = operatorWords[lang] || operatorWords.vi;
  const parts: string[] = [ops.ready];
  let currentSign: 'positive' | 'negative' | null = null;
  
  for (let i = 0; i < operands.length; i++) {
    const num = operands[i];
    const absNum = Math.abs(num);
    const isPositive = num >= 0;
    const word = numberToWords(absNum, lang);
    
    if (i === 0) {
      // First number - just say the number (capitalized)
      parts.push(word.charAt(0).toUpperCase() + word.slice(1));
      currentSign = isPositive ? 'positive' : 'negative';
    } else {
      const newSign = isPositive ? 'positive' : 'negative';
      
      if (newSign !== currentSign) {
        // Sign changed - say the operator with the number
        if (isPositive) {
          parts.push(ops.plus + ' ' + word);
        } else {
          parts.push(ops.minus + ' ' + word);
        }
        currentSign = newSign;
      } else {
        // Same sign - just say the number (comma separated in speech)
        // Add to previous part with comma
        parts[parts.length - 1] += ', ' + word;
      }
    }
  }
  
  parts.push(ops.equals);
  
  return parts.join('. ');
}

/**
 * Get available Vietnamese voices from Web Speech API
 */
export function getVietnameseVoices(): SpeechSynthesisVoice[] {
  const voices = window.speechSynthesis.getVoices();
  
  const vietnameseVoices = voices.filter(voice => 
    voice.lang === 'vi-VN' || 
    voice.lang === 'vi' || 
    voice.lang.startsWith('vi-') ||
    voice.name.toLowerCase().includes('vietnam')
  );
  
  return vietnameseVoices.sort((a, b) => {
    const aFemale = isFemaleVoice(a);
    const bFemale = isFemaleVoice(b);
    if (aFemale && !bFemale) return -1;
    if (!aFemale && bFemale) return 1;
    
    const aGoogle = a.name.toLowerCase().includes('google');
    const bGoogle = b.name.toLowerCase().includes('google');
    if (aGoogle && !bGoogle) return -1;
    if (!aGoogle && bGoogle) return 1;
    
    return 0;
  });
}

function isFemaleVoice(voice: SpeechSynthesisVoice): boolean {
  const name = voice.name.toLowerCase();
  return (
    name.includes('female') || name.includes('nữ') || name.includes('woman') ||
    name.includes('mai') || name.includes('linh') || name.includes('lan') ||
    (name.includes('google') && name.includes('vi'))
  );
}

/**
 * Speak text using Google Translate TTS via Edge Function
 */
export async function speakTextGoogle(
  text: string,
  lang: string = 'vi',
  onEnd?: () => void,
  onError?: (error: Error) => void
): Promise<void> {
  try {
    console.log('Calling Google TTS for:', text.substring(0, 50), 'lang:', lang);
    
    const { data, error } = await supabase.functions.invoke('google-tts', {
      body: { text, lang }
    });

    if (error) {
      console.error('Edge function error:', error);
      throw new Error(error.message);
    }

    if (!data?.audio) {
      throw new Error('No audio data received');
    }

    const audioData = atob(data.audio);
    const audioArray = new Uint8Array(audioData.length);
    for (let i = 0; i < audioData.length; i++) {
      audioArray[i] = audioData.charCodeAt(i);
    }

    const blob = new Blob([audioArray], { type: 'audio/mpeg' });
    const audioUrl = URL.createObjectURL(blob);
    const audio = new Audio(audioUrl);
    
    audio.onended = () => {
      URL.revokeObjectURL(audioUrl);
      onEnd?.();
    };
    
    audio.onerror = (e) => {
      console.error('Audio playback error:', e);
      URL.revokeObjectURL(audioUrl);
      onError?.(new Error('Audio playback failed'));
    };

    await audio.play();
    console.log('Google TTS playing...');

  } catch (error) {
    console.error('Google TTS error:', error);
    onError?.(error instanceof Error ? error : new Error('Unknown error'));
  }
}

/**
 * Speak text using Web Speech API (fallback)
 */
export function speakText(
  text: string, 
  speedMs: number = 1000,
  onEnd?: () => void,
  voiceURI?: string
): SpeechSynthesisUtterance | null {
  if (!('speechSynthesis' in window)) {
    console.error('Speech synthesis not supported');
    onEnd?.();
    return null;
  }
  
  window.speechSynthesis.cancel();
  
  const utterance = new SpeechSynthesisUtterance(text);
  const voices = window.speechSynthesis.getVoices();
  
  let selectedVoice: SpeechSynthesisVoice | undefined;
  
  if (voiceURI) {
    selectedVoice = voices.find(v => v.voiceURI === voiceURI);
  }
  
  if (!selectedVoice) {
    const vietnameseVoices = getVietnameseVoices();
    selectedVoice = vietnameseVoices[0];
  }
  
  if (!selectedVoice) {
    selectedVoice = voices.find(voice => 
      voice.lang === 'vi-VN'
    ) || voices.find(voice => 
      voice.lang.startsWith('vi')
    );
  }
  
  if (selectedVoice) {
    utterance.voice = selectedVoice;
    console.log('Using voice:', selectedVoice.name);
  }
  
  utterance.lang = 'vi-VN';
  const rate = Math.max(0.7, Math.min(1.3, 1.8 - (speedMs / 2500)));
  utterance.rate = rate;
  utterance.pitch = 1.0;
  utterance.volume = 1;
  
  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = () => onEnd();
  }
  
  window.speechSynthesis.speak(utterance);
  
  return utterance;
}

/**
 * Load voices (needed for some browsers)
 */
export function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(voices);
      return;
    }
    
    window.speechSynthesis.onvoiceschanged = () => {
      resolve(window.speechSynthesis.getVoices());
    };
    
    setTimeout(() => {
      resolve(window.speechSynthesis.getVoices());
    }, 1000);
  });
}