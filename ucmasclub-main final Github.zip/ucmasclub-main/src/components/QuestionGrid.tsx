import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useState, useEffect } from 'react';

interface QuestionGridProps {
  totalQuestions: number;
  currentQuestion: number;
  answers: (number | null)[];
  onSelectQuestion: (index: number) => void;
}

const QUESTIONS_PER_PAGE = 50;

export function QuestionGrid({ 
  totalQuestions, 
  currentQuestion, 
  answers, 
  onSelectQuestion 
}: QuestionGridProps) {
  const totalPages = Math.ceil(totalQuestions / QUESTIONS_PER_PAGE);
  const currentQuestionPage = Math.floor(currentQuestion / QUESTIONS_PER_PAGE);
  const [currentPage, setCurrentPage] = useState(currentQuestionPage);

  // Update page when current question changes to a different page
  useEffect(() => {
    const questionPage = Math.floor(currentQuestion / QUESTIONS_PER_PAGE);
    setCurrentPage(questionPage);
  }, [currentQuestion]);

  const startIndex = currentPage * QUESTIONS_PER_PAGE;
  const endIndex = Math.min(startIndex + QUESTIONS_PER_PAGE, totalQuestions);

  const getButtonVariant = (index: number) => {
    if (index === currentQuestion) return 'questionCurrent';
    if (answers[index] !== null) return 'questionAnswered';
    return 'question';
  };

  return (
    <div className="bg-card rounded-2xl shadow-card p-4 border border-border h-full flex flex-col">
      {/* Pagination */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
          disabled={currentPage === 0}
        >
          <ChevronLeft className="w-5 h-5" />
        </Button>
        
        <span className="text-sm font-bold text-foreground">
          {startIndex + 1} - {endIndex}
        </span>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCurrentPage(p => Math.min(totalPages - 1, p + 1))}
          disabled={currentPage === totalPages - 1}
        >
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-5 gap-2 flex-1 auto-rows-min overflow-y-auto">
        {Array.from({ length: endIndex - startIndex }, (_, i) => {
          const questionIndex = startIndex + i;
          return (
            <Button
              key={questionIndex}
              variant={getButtonVariant(questionIndex)}
              size="question"
              onClick={() => onSelectQuestion(questionIndex)}
              className="aspect-square text-xs font-bold"
            >
              {String(questionIndex + 1).padStart(2, '0')}
            </Button>
          );
        })}
      </div>

      {/* Stats */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded gradient-success" />
            <span className="text-muted-foreground">Đã làm: {answers.filter(a => a !== null).length}</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 rounded bg-card border-2 border-border" />
            <span className="text-muted-foreground">Chưa làm: {answers.filter(a => a === null).length}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
