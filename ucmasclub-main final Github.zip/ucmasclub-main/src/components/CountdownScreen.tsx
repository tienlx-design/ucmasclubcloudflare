import { useEffect, useState } from 'react';

interface CountdownScreenProps {
  onComplete: () => void;
}

export function CountdownScreen({ onComplete }: CountdownScreenProps) {
  const [count, setCount] = useState(3);
  const [show, setShow] = useState(true);

  useEffect(() => {
    if (count > 0) {
      const timer = setTimeout(() => {
        setShow(false);
        setTimeout(() => {
          setCount(count - 1);
          setShow(true);
        }, 100);
      }, 800);
      return () => clearTimeout(timer);
    } else {
      const timer = setTimeout(() => {
        onComplete();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [count, onComplete]);

  return (
    <div className="fixed inset-0 gradient-primary flex items-center justify-center z-50">
      <div className="text-center">
        <div 
          className={`text-[180px] md:text-[250px] font-black text-primary-foreground leading-none
            ${show ? 'animate-countdown-pop' : 'opacity-0'}`}
        >
          {count > 0 ? count : 'GO!'}
        </div>
        <p className="text-2xl md:text-3xl font-bold text-primary-foreground/80 mt-4">
          {count > 0 ? 'Chuẩn bị...' : 'Bắt đầu!'}
        </p>
      </div>
      
      {/* Decorative circles */}
      <div className="absolute top-20 left-20 w-40 h-40 rounded-full bg-white/5 animate-float" />
      <div className="absolute bottom-32 right-20 w-60 h-60 rounded-full bg-white/5 animate-float stagger-2" />
      <div className="absolute top-1/2 left-10 w-24 h-24 rounded-full bg-white/5 animate-float stagger-3" />
    </div>
  );
}
