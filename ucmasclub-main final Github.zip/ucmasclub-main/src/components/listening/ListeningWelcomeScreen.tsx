import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { StudentInfo, LEVELS, ExamSet, SPEECH_LANGUAGES } from '@/types/exam';
import { operandsToSpeech } from '@/utils/speechUtils';
import logo from '@/assets/logo_UCMAS.png';
import { Sparkles, User, GraduationCap, Timer, ArrowLeft, Headphones, FileText, Shuffle, Hash, Volume2, Play, Globe } from 'lucide-react';

interface ListeningWelcomeScreenProps {
  onStart: (studentInfo: StudentInfo) => void;
  onBack?: () => void;
}

// Sample exam sets for demo
const SAMPLE_EXAM_SETS: ExamSet[] = [
  { id: 'set-1', name: 'Đề nghe tính Cấp 3 - Tuần 1', level: 3, questionCount: 30, createdAt: new Date() },
  { id: 'set-2', name: 'Đề nghe tính Cấp 4 - Cơ bản', level: 4, questionCount: 30, createdAt: new Date() },
];

export function ListeningWelcomeScreen({ onStart, onBack }: ListeningWelcomeScreenProps) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [level, setLevel] = useState<number>(3);
  const [examSource, setExamSource] = useState<'auto' | 'preset'>('auto');
  const [selectedExamSet, setSelectedExamSet] = useState<string>('');
  const [readingSpeed, setReadingSpeed] = useState(1.5);
  const [errors, setErrors] = useState<{ name?: string }>({});
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<string>('google-translate');
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceType, setVoiceType] = useState<'google-translate' | 'browser'>('google-translate');
  const [speechLanguage, setSpeechLanguage] = useState<'vi' | 'en' | 'ru' | 'ms'>('vi');

  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      
      const vietnameseVoices = voices.filter(v => 
        v.lang === 'vi-VN' || v.lang === 'vi' || v.lang.startsWith('vi-') ||
        v.name.toLowerCase().includes('vietnam')
      );
      
      const sortedVoices = vietnameseVoices.sort((a, b) => {
        const aName = a.name.toLowerCase();
        const bName = b.name.toLowerCase();
        
        const femaleKeywords = ['female', 'nữ', 'woman', 'mai', 'linh', 'lan', 'huong', 'trang'];
        const aFemale = femaleKeywords.some(k => aName.includes(k)) || (aName.includes('google') && aName.includes('vi'));
        const bFemale = femaleKeywords.some(k => bName.includes(k)) || (bName.includes('google') && bName.includes('vi'));
        
        if (aFemale && !bFemale) return -1;
        if (!aFemale && bFemale) return 1;
        
        const aGoogle = aName.includes('google');
        const bGoogle = bName.includes('google');
        if (aGoogle && !bGoogle) return -1;
        if (!aGoogle && bGoogle) return 1;
        
        return 0;
      });
      
      setAvailableVoices(sortedVoices.length > 0 ? sortedVoices : voices.slice(0, 5));
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  const handlePreviewVoice = async () => {
    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    
    // Generate sample speech text based on selected language
    const sampleOperands = [5, -1, -2, 5, 4];
    const testText = operandsToSpeech(sampleOperands, speechLanguage);

    if (voiceType === 'google-translate') {
      try {
        const { supabase } = await import('@/integrations/supabase/client');
        const { data, error } = await supabase.functions.invoke('google-tts', {
          body: { text: testText, lang: speechLanguage }
        });

        if (error || !data?.audio) {
          throw new Error('Failed to get audio');
        }

        const audioData = atob(data.audio);
        const audioArray = new Uint8Array(audioData.length);
        for (let i = 0; i < audioData.length; i++) {
          audioArray[i] = audioData.charCodeAt(i);
        }

        const blob = new Blob([audioArray], { type: 'audio/mpeg' });
        const audioUrl = URL.createObjectURL(blob);
        const audio = new Audio(audioUrl);
        
        audio.onended = () => {
          URL.revokeObjectURL(audioUrl);
          setIsPlaying(false);
        };
        audio.onerror = () => {
          URL.revokeObjectURL(audioUrl);
          setIsPlaying(false);
        };
        
        await audio.play();
      } catch (e) {
        console.error('Google TTS preview error:', e);
        setIsPlaying(false);
      }
    } else {
      const utterance = new SpeechSynthesisUtterance(testText);
      const langCode = SPEECH_LANGUAGES.find(l => l.value === speechLanguage)?.code || 'vi-VN';
      utterance.lang = langCode;
      utterance.rate = 1;
      
      const voice = availableVoices.find(v => v.voiceURI === selectedVoice);
      if (voice) {
        utterance.voice = voice;
      }

      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);

      window.speechSynthesis.speak(utterance);
    }
  };

  const handleStart = () => {
    if (!name.trim()) {
      setErrors({ name: 'Vui lòng nhập tên thí sinh' });
      return;
    }
    
    onStart({
      name: name.trim(),
      code: code.trim() || undefined,
      level,
      examSource,
      examSetId: examSource === 'preset' ? selectedExamSet : undefined,
      readingSpeed,
      selectedVoice: voiceType === 'google-translate' ? 'google-translate' : selectedVoice,
      speechLanguage,
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-background via-background to-muted">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-secondary/10 animate-float" />
      <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-primary/10 animate-float stagger-2" />
      <div className="absolute top-1/3 right-20 w-16 h-16 rounded-full bg-accent/20 animate-float stagger-3" />
      
      <div className="w-full max-w-md animate-slide-up">
        {/* Back Button */}
        {onBack && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Quay lại
          </Button>
        )}

        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img 
            src={logo} 
            alt="UCMAS Logo" 
            className="h-20 w-auto animate-float"
          />
        </div>

        {/* Card */}
        <div className="bg-card rounded-2xl shadow-card p-8 border border-border">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Headphones className="w-8 h-8 text-secondary" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground mb-2">
              Luyện Tập <span className="text-secondary-foreground bg-secondary px-2 py-1 rounded-lg">Nghe Tính</span>
            </h1>
            <p className="text-muted-foreground">
              30 câu hỏi • Nghe đọc số
            </p>
          </div>

          <div className="space-y-5">
            {/* Name Input */}
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2 text-foreground font-semibold">
                <User className="w-4 h-4 text-secondary" />
                Họ và tên <span className="text-secondary">*</span>
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrors({});
                }}
                placeholder="Nhập tên của bạn"
                className="h-12 rounded-xl border-2 focus:border-secondary"
              />
              {errors.name && (
                <p className="text-sm text-secondary">{errors.name}</p>
              )}
            </div>

            {/* Student Code */}
            <div className="space-y-2">
              <Label htmlFor="code" className="flex items-center gap-2 text-foreground font-semibold">
                <Hash className="w-4 h-4 text-secondary" />
                Mã học sinh
              </Label>
              <Input
                id="code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Nhập mã học sinh (tùy chọn)"
                className="h-12 rounded-xl border-2 focus:border-secondary"
              />
            </div>

            {/* Level Select */}
            <div className="space-y-2">
              <Label htmlFor="level" className="flex items-center gap-2 text-foreground font-semibold">
                <GraduationCap className="w-4 h-4 text-secondary" />
                Cấp độ
              </Label>
              <Select value={String(level)} onValueChange={(v) => setLevel(Number(v))}>
                <SelectTrigger className="h-12 rounded-xl border-2">
                  <SelectValue placeholder="Chọn cấp độ" />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS.map((l) => (
                    <SelectItem key={l.value} value={String(l.value)}>
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Exam Source Selection */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <FileText className="w-4 h-4 text-secondary" />
                Nguồn đề
              </Label>
              <RadioGroup 
                value={examSource} 
                onValueChange={(value) => setExamSource(value as 'auto' | 'preset')}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="auto" id="auto" />
                  <Label htmlFor="auto" className="flex items-center gap-1 cursor-pointer">
                    <Shuffle className="w-4 h-4" />
                    Tự động sinh đề
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="preset" id="preset" />
                  <Label htmlFor="preset" className="flex items-center gap-1 cursor-pointer">
                    <FileText className="w-4 h-4" />
                    Chọn từ kho đề
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Preset Exam Select */}
            {examSource === 'preset' && (
              <div className="space-y-2 animate-slide-up">
                <Label className="flex items-center gap-2 text-foreground font-semibold">
                  Chọn đề luyện tập
                </Label>
                <Select value={selectedExamSet} onValueChange={setSelectedExamSet}>
                  <SelectTrigger className="h-12 rounded-xl border-2 border-accent">
                    <SelectValue placeholder="Chọn đề từ kho" />
                  </SelectTrigger>
                  <SelectContent>
                    {SAMPLE_EXAM_SETS.map((set) => (
                      <SelectItem key={set.id} value={set.id}>
                        {set.name} (Cấp {set.level})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Voice Type Selection */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <Volume2 className="w-4 h-4 text-secondary" />
                Giọng đọc
              </Label>
              <RadioGroup 
                value={voiceType} 
                onValueChange={(value) => setVoiceType(value as 'google-translate' | 'browser')}
                className="space-y-2"
              >
                <div className={`flex items-center space-x-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${voiceType === 'google-translate' ? 'border-secondary bg-secondary/10' : 'border-border'}`}>
                  <RadioGroupItem value="google-translate" id="google-translate" />
                  <Label htmlFor="google-translate" className="cursor-pointer flex-1">
                    <span className="font-semibold">🌐 Google Dịch (Khuyên dùng)</span>
                    <p className="text-xs text-muted-foreground">Giọng đọc rõ ràng, tự nhiên</p>
                  </Label>
                </div>
                <div className={`flex items-center space-x-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${voiceType === 'browser' ? 'border-secondary bg-secondary/10' : 'border-border'}`}>
                  <RadioGroupItem value="browser" id="browser" />
                  <Label htmlFor="browser" className="cursor-pointer flex-1">
                    <span className="font-semibold">🖥️ Giọng trình duyệt</span>
                    <p className="text-xs text-muted-foreground">Sử dụng giọng có sẵn trên thiết bị</p>
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Language Selection - only show if Google Translate selected */}
            {voiceType === 'google-translate' && (
              <div className="space-y-2 animate-slide-up">
                <Label className="flex items-center gap-2 text-foreground font-semibold">
                  <Globe className="w-4 h-4 text-secondary" />
                  Ngôn ngữ đọc
                </Label>
                <Select value={speechLanguage} onValueChange={(v) => setSpeechLanguage(v as 'vi' | 'en' | 'ru' | 'ms')}>
                  <SelectTrigger className="h-12 rounded-xl border-2">
                    <SelectValue placeholder="Chọn ngôn ngữ" />
                  </SelectTrigger>
                  <SelectContent>
                    {SPEECH_LANGUAGES.map((lang) => (
                      <SelectItem key={lang.value} value={lang.value}>
                        {lang.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Browser Voice Select - only show if browser voice selected */}
            {voiceType === 'browser' && (
              <div className="space-y-2 animate-slide-up">
                <Label className="text-sm font-semibold text-foreground">
                  Chọn giọng trình duyệt
                </Label>
                <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                  <SelectTrigger className="h-12 rounded-xl border-2">
                    <SelectValue placeholder="Chọn giọng đọc" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableVoices.map((voice) => (
                      <SelectItem key={voice.voiceURI} value={voice.voiceURI}>
                        {voice.name} ({voice.lang})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Preview Button */}
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                className="flex-1 h-12 rounded-xl"
                onClick={handlePreviewVoice}
                disabled={isPlaying}
              >
                <Play className={`w-5 h-5 mr-2 ${isPlaying ? 'text-secondary animate-pulse' : ''}`} />
                {isPlaying ? 'Đang phát...' : 'Nghe thử giọng đọc'}
              </Button>
            </div>

            {/* Reading Speed Slider */}
            <div className="space-y-4">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <Timer className="w-4 h-4 text-secondary" />
                Tốc độ đọc: <span className="text-secondary font-bold">{readingSpeed.toFixed(1)}s</span>
              </Label>
              <div className="px-2">
                <Slider
                  value={[readingSpeed]}
                  onValueChange={([value]) => setReadingSpeed(value)}
                  min={0.5}
                  max={3}
                  step={0.1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>Nhanh (0.5s)</span>
                  <span>Chậm (3s)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Start Button */}
          <Button 
            variant="hero" 
            size="xl" 
            className="w-full mt-8 gradient-secondary hover:opacity-90"
            onClick={handleStart}
          >
            <Sparkles className="w-6 h-6" />
            BẮT ĐẦU LUYỆN TẬP
          </Button>
        </div>

        {/* Footer */}
        <p className="text-center text-muted-foreground text-sm mt-6">
          UCMAS Club - Education With A Difference
        </p>
      </div>
    </div>
  );
}