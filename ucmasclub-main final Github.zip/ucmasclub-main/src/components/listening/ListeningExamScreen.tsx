import { useState, useEffect, useCallback, useRef } from 'react';
import { Question, StudentInfo, ExamResult } from '@/types/exam';
import { ListeningQuestionDisplay } from './ListeningQuestionDisplay';
import { ListeningTimerPanel } from './ListeningTimerPanel';
import { CompletionPopup } from '@/components/CompletionPopup';
import { operandsToSpeech, speakText, speakTextGoogle } from '@/utils/speechUtils';

interface ListeningExamScreenProps {
  studentInfo: StudentInfo;
  examData: Question[];
  onFinish: (result: ExamResult) => void;
}

const ANSWER_TIME = 10; // 10 seconds to answer

type QuestionState = 'waiting' | 'playing' | 'answering' | 'completed';

export function ListeningExamScreen({ studentInfo, examData, onFinish }: ListeningExamScreenProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(
    new Array(examData.length).fill(null)
  );
  const [questionState, setQuestionState] = useState<QuestionState>('waiting');
  const [answerTimeRemaining, setAnswerTimeRemaining] = useState(ANSWER_TIME);
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  const [startTime] = useState(Date.now());
  const [hasListened, setHasListened] = useState<boolean[]>(
    new Array(examData.length).fill(false)
  );
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const readingSpeedMs = (studentInfo.readingSpeed || 1.5) * 1000;
  const useGoogleTTS = studentInfo.selectedVoice === 'google-translate';

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      window.speechSynthesis.cancel();
    };
  }, []);

  // Answer timer countdown
  useEffect(() => {
    if (questionState === 'answering') {
      timerRef.current = setInterval(() => {
        setAnswerTimeRemaining(prev => {
          if (prev <= 1) {
            // Time's up - move to next question
            handleTimeUp();
            return ANSWER_TIME;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [questionState, currentQuestion]);

  const handleTimeUp = useCallback(() => {
    if (currentQuestion < examData.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
    } else {
      // Last question - check if all answered
      checkCompletion();
    }
  }, [currentQuestion, examData.length]);

  const checkCompletion = useCallback(() => {
    const allAnswered = answers.every(a => a !== null);
    if (allAnswered) {
      setShowCompletionPopup(true);
    } else {
      // Find first unanswered question
      const firstUnanswered = answers.findIndex(a => a === null);
      if (firstUnanswered !== -1 && !hasListened[firstUnanswered]) {
        setCurrentQuestion(firstUnanswered);
        setQuestionState('waiting');
      } else {
        setShowCompletionPopup(true);
      }
    }
  }, [answers, hasListened]);

  const handlePlayAudio = useCallback(async () => {
    if (hasListened[currentQuestion]) return;
    
    const question = examData[currentQuestion];
    const lang = studentInfo.speechLanguage || 'vi';
    const speechText = operandsToSpeech(question.operands, lang);
    
    setQuestionState('playing');
    
    // Mark as listened
    setHasListened(prev => {
      const newListened = [...prev];
      newListened[currentQuestion] = true;
      return newListened;
    });

    const onSpeechEnd = () => {
      setQuestionState('answering');
      setAnswerTimeRemaining(ANSWER_TIME);
    };

    // Use Google TTS or fallback to Web Speech API
    if (useGoogleTTS) {
      await speakTextGoogle(
        speechText,
        lang,
        onSpeechEnd,
        (error) => {
          console.error('Google TTS failed:', error);
          // Fallback to Web Speech API
          speakText(speechText, readingSpeedMs, onSpeechEnd, studentInfo.selectedVoice);
        }
      );
    } else {
      speakText(speechText, readingSpeedMs, onSpeechEnd, studentInfo.selectedVoice);
    }
  }, [currentQuestion, examData, hasListened, readingSpeedMs, studentInfo.selectedVoice, studentInfo.speechLanguage, useGoogleTTS]);

  const handleSubmitAnswer = useCallback((answer: number) => {
    if (questionState !== 'answering') return;
    
    setAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[currentQuestion] = answer;
      return newAnswers;
    });

    // Clear timer
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    // Move to next question or finish
    if (currentQuestion < examData.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
    } else {
      // Last question - check completion
      setTimeout(() => {
        checkCompletion();
      }, 100);
    }
  }, [questionState, currentQuestion, examData.length, checkCompletion]);

  const handleNavigate = (index: number) => {
    // Only allow navigation to unanswered questions that haven't been listened
    if (!hasListened[index] && answers[index] === null) {
      setCurrentQuestion(index);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
    }
  };

  const handleFinish = useCallback(() => {
    const timeUsed = Math.round((Date.now() - startTime) / 1000);
    const correctCount = answers.filter(
      (a, i) => a !== null && a === examData[i].correct
    ).length;

    const result: ExamResult = {
      studentInfo,
      totalQuestions: examData.length,
      totalAnswered: answers.filter(a => a !== null).length,
      correctCount,
      timeUsed,
      answers,
      createdAt: new Date(),
      practiceType: 'listening',
    };

    onFinish(result);
  }, [startTime, answers, examData, studentInfo, onFinish]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted p-4">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Panel - Question Display */}
          <div className="lg:col-span-2">
            <ListeningQuestionDisplay
              question={examData[currentQuestion]}
              currentIndex={currentQuestion}
              totalQuestions={examData.length}
              questionState={questionState}
              answerTimeRemaining={answerTimeRemaining}
              hasListened={hasListened[currentQuestion]}
              onPlayAudio={handlePlayAudio}
              onSubmitAnswer={handleSubmitAnswer}
            />
          </div>

          {/* Right Panel - Timer & Progress */}
          <div className="lg:col-span-1">
            <ListeningTimerPanel
              studentInfo={studentInfo}
              currentQuestion={currentQuestion}
              totalQuestions={examData.length}
              answers={answers}
              hasListened={hasListened}
              onNavigate={handleNavigate}
              onFinish={() => setShowCompletionPopup(true)}
            />
          </div>
        </div>
      </div>

      {/* Completion Popup */}
      {showCompletionPopup && (
        <CompletionPopup
          onContinue={() => setShowCompletionPopup(false)}
          onFinish={handleFinish}
          totalQuestions={examData.length}
        />
      )}
    </div>
  );
}