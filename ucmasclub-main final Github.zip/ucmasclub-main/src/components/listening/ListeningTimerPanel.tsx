import { Button } from '@/components/ui/button';
import { StudentInfo } from '@/types/exam';
import { User, GraduationCap, Timer, CheckCircle2, Headphones, Hash, Volume2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ListeningTimerPanelProps {
  studentInfo: StudentInfo;
  currentQuestion: number;
  totalQuestions: number;
  answers: (number | null)[];
  hasListened: boolean[];
  onNavigate: (index: number) => void;
  onFinish: () => void;
}

export function ListeningTimerPanel({
  studentInfo,
  currentQuestion,
  totalQuestions,
  answers,
  hasListened,
  onNavigate,
  onFinish,
}: ListeningTimerPanelProps) {
  const answeredCount = answers.filter(a => a !== null).length;

  return (
    <div className="bg-card rounded-2xl shadow-card p-6 border border-border space-y-6">
      {/* Student Info */}
      <div className="space-y-3">
        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <User className="w-5 h-5 text-secondary" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground">Thí sinh</p>
            <p className="font-bold text-foreground truncate">{studentInfo.name}</p>
          </div>
        </div>

        {studentInfo.code && (
          <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
            <Hash className="w-5 h-5 text-secondary" />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Mã học sinh</p>
              <p className="font-bold text-foreground">{studentInfo.code}</p>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <GraduationCap className="w-5 h-5 text-secondary" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Cấp độ</p>
            <p className="font-bold text-foreground">Cấp {studentInfo.level}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <Timer className="w-5 h-5 text-secondary" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Tốc độ đọc</p>
            <p className="font-bold text-foreground">{studentInfo.readingSpeed?.toFixed(1) || '1.5'}s</p>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-foreground">Tiến độ</span>
          <span className="text-sm font-bold text-secondary">
            {answeredCount}/{totalQuestions}
          </span>
        </div>

        {/* Question Grid */}
        <div className="grid grid-cols-6 gap-2">
          {Array.from({ length: totalQuestions }, (_, i) => {
            const isAnswered = answers[i] !== null;
            const isCurrent = i === currentQuestion;
            const listened = hasListened[i];

            return (
              <button
                key={i}
                onClick={() => onNavigate(i)}
                disabled={listened || isAnswered}
                className={cn(
                  'w-full aspect-square rounded-lg text-sm font-bold transition-all',
                  'flex items-center justify-center',
                  isCurrent && 'ring-2 ring-secondary ring-offset-2',
                  isAnswered && 'bg-success text-success-foreground',
                  !isAnswered && listened && 'bg-muted text-muted-foreground opacity-50',
                  !isAnswered && !listened && 'bg-muted text-muted-foreground hover:bg-secondary/20',
                )}
              >
                {isAnswered ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : listened ? (
                  <Headphones className="w-4 h-4" />
                ) : (
                  i + 1
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-3 text-xs">
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded bg-success" />
          <span>Đã trả lời</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded bg-muted flex items-center justify-center">
            <Headphones className="w-3 h-3" />
          </div>
          <span>Đã nghe</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-4 h-4 rounded bg-muted" />
          <span>Chưa làm</span>
        </div>
      </div>

      {/* Finish Button */}
      <Button
        variant="hero"
        size="lg"
        className="w-full gradient-secondary hover:opacity-90"
        onClick={onFinish}
      >
        <CheckCircle2 className="w-5 h-5 mr-2" />
        Hoàn thành ({answeredCount}/{totalQuestions})
      </Button>
    </div>
  );
}