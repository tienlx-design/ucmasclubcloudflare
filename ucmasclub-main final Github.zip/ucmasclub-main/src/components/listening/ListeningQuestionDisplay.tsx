import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Question } from '@/types/exam';
import { Volume2, Play, Clock, Send, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ListeningQuestionDisplayProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  questionState: 'waiting' | 'playing' | 'answering' | 'completed';
  answerTimeRemaining: number;
  hasListened: boolean;
  onPlayAudio: () => void;
  onSubmitAnswer: (answer: number) => void;
}

export function ListeningQuestionDisplay({
  question,
  currentIndex,
  totalQuestions,
  questionState,
  answerTimeRemaining,
  hasListened,
  onPlayAudio,
  onSubmitAnswer,
}: ListeningQuestionDisplayProps) {
  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when state changes to answering
  useEffect(() => {
    if (questionState === 'answering' && inputRef.current) {
      inputRef.current.focus();
    }
  }, [questionState]);

  // Reset input when question changes
  useEffect(() => {
    setInputValue('');
  }, [currentIndex]);

  const handleSubmit = () => {
    const value = parseInt(inputValue, 10);
    if (!isNaN(value)) {
      onSubmitAnswer(value);
      setInputValue('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  // Timer color based on remaining time
  const getTimerColor = () => {
    if (answerTimeRemaining <= 3) return 'text-destructive';
    if (answerTimeRemaining <= 5) return 'text-accent';
    return 'text-success';
  };

  return (
    <div className="bg-card rounded-2xl shadow-card p-6 border border-border">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full gradient-secondary flex items-center justify-center shadow-glow-secondary">
            <span className="text-lg font-bold text-secondary-foreground">
              {currentIndex + 1}
            </span>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Câu hỏi</p>
            <p className="font-bold text-foreground">
              {currentIndex + 1} / {totalQuestions}
            </p>
          </div>
        </div>

        {/* Answer Timer */}
        {questionState === 'answering' && (
          <div className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-full bg-muted',
            getTimerColor()
          )}>
            <Clock className="w-5 h-5" />
            <span className="text-2xl font-bold tabular-nums">
              {answerTimeRemaining}s
            </span>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex flex-col items-center justify-center min-h-[300px] space-y-8">
        {/* Waiting State - Show Play Button */}
        {questionState === 'waiting' && !hasListened && (
          <>
            <div className="w-32 h-32 rounded-full gradient-secondary flex items-center justify-center animate-pulse-soft">
              <Volume2 className="w-16 h-16 text-secondary-foreground" />
            </div>
            <Button
              variant="hero"
              size="xl"
              onClick={onPlayAudio}
              className="gradient-secondary hover:opacity-90"
            >
              <Play className="w-6 h-6 mr-2" />
              Bắt đầu nghe
            </Button>
            <p className="text-muted-foreground text-center">
              Nhấn nút để nghe câu hỏi. <br />
              <span className="text-secondary font-semibold">Mỗi câu chỉ được nghe 1 lần!</span>
            </p>
          </>
        )}

        {/* Playing State - Audio is playing */}
        {questionState === 'playing' && (
          <>
            <div className="w-32 h-32 rounded-full gradient-secondary flex items-center justify-center animate-pulse">
              <Volume2 className="w-16 h-16 text-secondary-foreground animate-bounce" />
            </div>
            <div className="flex items-center gap-3 text-secondary">
              <Loader2 className="w-6 h-6 animate-spin" />
              <span className="text-xl font-bold">Đang đọc...</span>
            </div>
          </>
        )}

        {/* Answering State - Show Input */}
        {questionState === 'answering' && (
          <>
            <div className="w-full max-w-xs space-y-4">
              <p className="text-center text-muted-foreground mb-4">
                Nhập đáp án của bạn
              </p>
              <Input
                ref={inputRef}
                type="number"
                inputMode="numeric"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Nhập số..."
                className="h-16 text-3xl text-center font-bold rounded-xl border-2 border-secondary focus:border-secondary"
              />
              <Button
                variant="hero"
                size="xl"
                onClick={handleSubmit}
                disabled={!inputValue}
                className="w-full gradient-secondary hover:opacity-90"
              >
                <Send className="w-5 h-5 mr-2" />
                Gửi đáp án
              </Button>
            </div>

            {/* Progress bar for timer */}
            <div className="w-full max-w-xs">
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={cn(
                    'h-full transition-all duration-1000 rounded-full',
                    answerTimeRemaining <= 3 ? 'bg-destructive' :
                    answerTimeRemaining <= 5 ? 'bg-accent' : 'bg-success'
                  )}
                  style={{ width: `${(answerTimeRemaining / 10) * 100}%` }}
                />
              </div>
            </div>
          </>
        )}

        {/* Already Listened - Cannot listen again */}
        {questionState === 'waiting' && hasListened && (
          <div className="text-center text-muted-foreground">
            <Volume2 className="w-16 h-16 mx-auto mb-4 opacity-30" />
            <p>Bạn đã nghe câu hỏi này rồi</p>
          </div>
        )}
      </div>
    </div>
  );
}
