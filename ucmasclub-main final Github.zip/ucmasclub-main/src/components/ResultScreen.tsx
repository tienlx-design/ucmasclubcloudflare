import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ExamResult, Question } from '@/types/exam';
import { formatTimeVerbose } from '@/utils/examGenerator';
import { Trophy, Clock, Target, CheckCircle, RefreshCw, Star, Home, Eye, X, ChevronLeft, ChevronRight } from 'lucide-react';
import logo from '@/assets/logo_UCMAS.png';
import { cn } from '@/lib/utils';

interface ResultScreenProps {
  result: ExamResult;
  examData: Question[];
  onRestart: () => void;
  onBackToHome?: () => void;
}

export function ResultScreen({ result, examData, onRestart, onBackToHome }: ResultScreenProps) {
  const [showReview, setShowReview] = useState(false);
  const [reviewPage, setReviewPage] = useState(0);
  const ITEMS_PER_PAGE = 10;

  const percentage = Math.round((result.correctCount / result.totalQuestions) * 100);
  
  const getGrade = () => {
    if (percentage >= 90) return { label: 'Xuất sắc!', color: 'text-success', stars: 5 };
    if (percentage >= 80) return { label: 'Giỏi!', color: 'text-primary', stars: 4 };
    if (percentage >= 70) return { label: 'Khá!', color: 'text-ucmas-blue-light', stars: 3 };
    if (percentage >= 60) return { label: 'Trung bình', color: 'text-accent', stars: 2 };
    return { label: 'Cần cố gắng hơn', color: 'text-muted-foreground', stars: 1 };
  };

  const grade = getGrade();

  // Review data
  const reviewData = examData.map((q, index) => ({
    question: q,
    userAnswer: result.answers[index],
    isCorrect: result.answers[index] === q.correct,
    index,
  }));

  const totalPages = Math.ceil(reviewData.length / ITEMS_PER_PAGE);
  const paginatedReview = reviewData.slice(
    reviewPage * ITEMS_PER_PAGE,
    (reviewPage + 1) * ITEMS_PER_PAGE
  );

  if (showReview) {
    return (
      <div className="min-h-screen p-6 bg-gradient-to-br from-background via-background to-muted">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Button
              variant="ghost"
              onClick={() => setShowReview(false)}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Quay lại
            </Button>
            <h1 className="text-2xl font-bold text-foreground">
              Xem lại kết quả
            </h1>
            <div className="w-24" />
          </div>

          {/* Summary */}
          <div className="bg-card rounded-xl p-4 mb-6 border border-border flex items-center justify-between">
            <div>
              <span className="text-muted-foreground">Tổng điểm:</span>
              <span className="ml-2 font-bold text-primary">
                {result.correctCount}/{result.totalQuestions} ({percentage}%)
              </span>
            </div>
            <div className="flex gap-2">
              <span className="px-3 py-1 rounded-full bg-success/20 text-success text-sm font-medium">
                Đúng: {result.correctCount}
              </span>
              <span className="px-3 py-1 rounded-full bg-destructive/20 text-destructive text-sm font-medium">
                Sai: {result.totalAnswered - result.correctCount}
              </span>
              <span className="px-3 py-1 rounded-full bg-muted text-muted-foreground text-sm font-medium">
                Bỏ qua: {result.totalQuestions - result.totalAnswered}
              </span>
            </div>
          </div>

          {/* Review Grid */}
          <div className="grid gap-4">
            {paginatedReview.map(({ question, userAnswer, isCorrect, index }) => (
              <div
                key={index}
                className={cn(
                  'bg-card rounded-xl p-4 border',
                  isCorrect ? 'border-success/50' : 'border-destructive/50'
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center font-bold',
                      isCorrect ? 'bg-success/20 text-success' : 'bg-destructive/20 text-destructive'
                    )}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Phép tính:</p>
                      <p className="font-mono text-lg">
                        {question.operands.map((op, i) => {
                          if (i === 0) return op;
                          return op >= 0 ? ` + ${op}` : ` - ${Math.abs(op)}`;
                        }).join('')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Đáp án của bạn</p>
                        <p className={cn(
                          'text-xl font-bold',
                          userAnswer === null ? 'text-muted-foreground' :
                          isCorrect ? 'text-success' : 'text-destructive'
                        )}>
                          {userAnswer === null ? '—' : userAnswer}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Đáp án đúng</p>
                        <p className="text-xl font-bold text-success">
                          {question.correct}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-4 mt-6">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setReviewPage(p => Math.max(0, p - 1))}
                disabled={reviewPage === 0}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="text-sm text-muted-foreground">
                Trang {reviewPage + 1} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setReviewPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={reviewPage === totalPages - 1}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-background via-background to-muted">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-success/10 animate-float" />
      <div className="absolute bottom-20 right-20 w-40 h-40 rounded-full bg-primary/10 animate-float stagger-2" />
      
      <div className="w-full max-w-lg animate-slide-up">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <img src={logo} alt="UCMAS" className="h-16 w-auto" />
        </div>

        {/* Result Card */}
        <div className="bg-card rounded-2xl shadow-card p-8 border border-border">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 rounded-full gradient-success mx-auto flex items-center justify-center mb-4 shadow-glow-primary">
              <Trophy className="w-10 h-10 text-success-foreground" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground mb-2">
              Kết Quả Bài Thi
            </h1>
            <p className="text-muted-foreground">
              {result.studentInfo.name} • {result.studentInfo.level}
              {result.practiceType && (
                <span className="ml-2 text-secondary">
                  ({result.practiceType === 'visual' ? 'Nhìn tính' : 'Nghe tính'})
                </span>
              )}
            </p>
          </div>

          {/* Stars */}
          <div className="flex justify-center gap-2 mb-6">
            {Array.from({ length: 5 }, (_, i) => (
              <Star 
                key={i} 
                className={`w-8 h-8 ${i < grade.stars ? 'text-accent fill-accent' : 'text-muted'}`} 
              />
            ))}
          </div>

          {/* Grade */}
          <div className="text-center mb-8">
            <p className={`text-2xl font-extrabold ${grade.color}`}>
              {grade.label}
            </p>
          </div>

          {/* Score Display */}
          <div className="bg-muted rounded-2xl p-6 mb-6">
            <div className="text-center">
              <div className="text-6xl font-black text-primary mb-2">
                {result.correctCount}
                <span className="text-3xl text-muted-foreground">/{result.totalQuestions}</span>
              </div>
              <p className="text-lg font-semibold text-muted-foreground">
                Số câu đúng ({percentage}%)
              </p>
            </div>

            {/* Progress Bar */}
            <div className="mt-4">
              <div className="h-4 bg-background rounded-full overflow-hidden">
                <div 
                  className="h-full gradient-success transition-all duration-1000 rounded-full"
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-muted rounded-xl p-4 text-center">
              <Target className="w-6 h-6 text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold text-foreground">{result.totalAnswered}</p>
              <p className="text-xs text-muted-foreground">Đã làm</p>
            </div>
            <div className="bg-muted rounded-xl p-4 text-center">
              <CheckCircle className="w-6 h-6 text-success mx-auto mb-2" />
              <p className="text-2xl font-bold text-foreground">{result.correctCount}</p>
              <p className="text-xs text-muted-foreground">Đúng</p>
            </div>
            <div className="bg-muted rounded-xl p-4 text-center">
              <Clock className="w-6 h-6 text-secondary mx-auto mb-2" />
              <p className="text-lg font-bold text-foreground">{formatTimeVerbose(result.timeUsed)}</p>
              <p className="text-xs text-muted-foreground">Thời gian</p>
            </div>
          </div>

          {/* Review Button */}
          <Button 
            variant="outline" 
            size="lg" 
            className="w-full mb-4"
            onClick={() => setShowReview(true)}
          >
            <Eye className="w-5 h-5 mr-2" />
            Xem lại kết quả
          </Button>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-4">
            <Button 
              variant="outline" 
              size="lg"
              onClick={onBackToHome}
            >
              <Home className="w-5 h-5 mr-2" />
              Trang chủ
            </Button>
            <Button 
              variant="hero" 
              size="lg"
              onClick={onRestart}
            >
              <RefreshCw className="w-5 h-5 mr-2" />
              Làm lại
            </Button>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-muted-foreground text-sm mt-6">
          UCMAS Club - Education With A Difference
        </p>
      </div>
    </div>
  );
}
