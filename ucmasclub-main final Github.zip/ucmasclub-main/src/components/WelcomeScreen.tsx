import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { StudentInfo, LEVELS, ExamSet } from '@/types/exam';
import logo from '@/assets/logo_UCMAS.png';
import { Sparkles, User, GraduationCap, FileText, Shuffle, ArrowLeft, Eye, Hash } from 'lucide-react';

interface WelcomeScreenProps {
  onStart: (studentInfo: StudentInfo) => void;
  onBack?: () => void;
  examSets?: ExamSet[];
}

// Sample exam sets for demo - will be replaced with Supabase data
const SAMPLE_EXAM_SETS: ExamSet[] = [
  { id: 'set-1', name: 'Đề luyện tập Cấp 3 - Tuần 1', level: 3, questionCount: 200, createdAt: new Date() },
  { id: 'set-2', name: 'Đề luyện tập Cấp 4 - Cơ bản', level: 4, questionCount: 200, createdAt: new Date() },
  { id: 'set-3', name: 'Đề thi thử Cấp 5', level: 5, questionCount: 200, createdAt: new Date() },
];

export function WelcomeScreen({ onStart, onBack, examSets = SAMPLE_EXAM_SETS }: WelcomeScreenProps) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [level, setLevel] = useState<number>(3);
  const [examSource, setExamSource] = useState<'auto' | 'preset'>('auto');
  const [selectedExamSet, setSelectedExamSet] = useState<string>('');
  const [errors, setErrors] = useState<{ name?: string }>({});

  const filteredExamSets = examSets.filter(set => set.level === level || examSource === 'preset');

  const handleStart = () => {
    if (!name.trim()) {
      setErrors({ name: 'Vui lòng nhập tên thí sinh' });
      return;
    }
    
    onStart({
      name: name.trim(),
      code: code.trim() || undefined,
      level,
      examSource,
      examSetId: examSource === 'preset' ? selectedExamSet : undefined,
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-background via-background to-muted">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-primary/10 animate-float" />
      <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-secondary/10 animate-float stagger-2" />
      <div className="absolute top-1/3 right-20 w-16 h-16 rounded-full bg-accent/20 animate-float stagger-3" />
      
      <div className="w-full max-w-md animate-slide-up">
        {/* Back Button */}
        {onBack && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Quay lại
          </Button>
        )}

        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img 
            src={logo} 
            alt="UCMAS Logo" 
            className="h-20 w-auto animate-float"
          />
        </div>

        {/* Card */}
        <div className="bg-card rounded-2xl shadow-card p-8 border border-border">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Eye className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground mb-2">
              Luyện Tập <span className="text-primary-foreground bg-primary px-2 py-1 rounded-lg">Nhìn Tính</span>
            </h1>
            <p className="text-muted-foreground">
              200 câu hỏi • 8 phút
            </p>
          </div>

          <div className="space-y-5">
            {/* Name Input */}
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2 text-foreground font-semibold">
                <User className="w-4 h-4 text-primary" />
                Họ và tên <span className="text-secondary">*</span>
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrors({});
                }}
                placeholder="Nhập tên của bạn"
                className="h-12 rounded-xl border-2 focus:border-primary"
              />
              {errors.name && (
                <p className="text-sm text-secondary">{errors.name}</p>
              )}
            </div>

            {/* Student Code */}
            <div className="space-y-2">
              <Label htmlFor="code" className="flex items-center gap-2 text-foreground font-semibold">
                <Hash className="w-4 h-4 text-primary" />
                Mã học sinh
              </Label>
              <Input
                id="code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Nhập mã học sinh (tùy chọn)"
                className="h-12 rounded-xl border-2 focus:border-primary"
              />
            </div>

            {/* Level Select */}
            <div className="space-y-2">
              <Label htmlFor="level" className="flex items-center gap-2 text-foreground font-semibold">
                <GraduationCap className="w-4 h-4 text-primary" />
                Cấp độ
              </Label>
              <Select value={String(level)} onValueChange={(v) => setLevel(Number(v))}>
                <SelectTrigger className="h-12 rounded-xl border-2">
                  <SelectValue placeholder="Chọn cấp độ" />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS.map((l) => (
                    <SelectItem key={l.value} value={String(l.value)}>
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Exam Source Selection */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <FileText className="w-4 h-4 text-primary" />
                Nguồn đề
              </Label>
              <RadioGroup 
                value={examSource} 
                onValueChange={(value) => setExamSource(value as 'auto' | 'preset')}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="auto" id="auto" />
                  <Label htmlFor="auto" className="flex items-center gap-1 cursor-pointer">
                    <Shuffle className="w-4 h-4" />
                    Tự động sinh đề
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="preset" id="preset" />
                  <Label htmlFor="preset" className="flex items-center gap-1 cursor-pointer">
                    <FileText className="w-4 h-4" />
                    Chọn từ kho đề
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Exam Set Selection - Only show when preset is selected */}
            {examSource === 'preset' && (
              <div className="space-y-2 animate-slide-up">
                <Label className="flex items-center gap-2 text-foreground font-semibold">
                  Chọn đề luyện tập
                </Label>
                <Select value={selectedExamSet} onValueChange={setSelectedExamSet}>
                  <SelectTrigger className="h-12 rounded-xl border-2 border-accent">
                    <SelectValue placeholder="Chọn đề từ kho" />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredExamSets.length > 0 ? (
                      filteredExamSets.map((set) => (
                        <SelectItem key={set.id} value={set.id}>
                          {set.name} (Cấp {set.level})
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="none" disabled>
                        Chưa có đề nào trong kho
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Kho đề sẽ được cập nhật thường xuyên
                </p>
              </div>
            )}
          </div>

          {/* Start Button */}
          <Button 
            variant="hero" 
            size="xl" 
            className="w-full mt-8"
            onClick={handleStart}
          >
            <Sparkles className="w-6 h-6" />
            BẮT ĐẦU LUYỆN TẬP
          </Button>
        </div>

        {/* Footer */}
        <p className="text-center text-muted-foreground text-sm mt-6">
          UCMAS Club - Education With A Difference
        </p>
      </div>
    </div>
  );
}