import { Button } from '@/components/ui/button';
import { PartyPopper, Search, Trophy } from 'lucide-react';

interface CompletionPopupProps {
  onContinue: () => void;
  onFinish: () => void;
  totalQuestions: number;
}

export function CompletionPopup({ onContinue, onFinish, totalQuestions }: CompletionPopupProps) {
  return (
    <div className="fixed inset-0 bg-foreground/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-card p-8 max-w-md w-full animate-bounce-in border border-border">
        <div className="text-center">
          {/* Icon */}
          <div className="w-24 h-24 rounded-full gradient-success mx-auto flex items-center justify-center mb-6 shadow-glow-primary">
            <PartyPopper className="w-12 h-12 text-success-foreground" />
          </div>

          {/* Title */}
          <h2 className="text-3xl font-extrabold text-foreground mb-2">
            🎉 Chúc mừng!
          </h2>

          {/* Message */}
          <p className="text-lg text-muted-foreground mb-8">
            Bạn đã hoàn thành <span className="font-bold text-primary">{totalQuestions}</span> câu hỏi!
          </p>

          {/* Buttons */}
          <div className="space-y-3">
            <Button 
              variant="outline" 
              size="lg" 
              className="w-full"
              onClick={onContinue}
            >
              <Search className="w-5 h-5" />
              Kiểm tra lại bài làm
            </Button>
            <Button 
              variant="hero" 
              size="lg" 
              className="w-full"
              onClick={onFinish}
            >
              <Trophy className="w-5 h-5" />
              Hoàn thành bài thi
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
