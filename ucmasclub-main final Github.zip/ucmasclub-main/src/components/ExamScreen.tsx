import { useState, useEffect, useCallback } from 'react';
import { Question, StudentInfo, ExamResult } from '@/types/exam';
import { QuestionGrid } from './QuestionGrid';
import { QuestionDisplay } from './QuestionDisplay';
import { TimerPanel } from './TimerPanel';
import { CompletionPopup } from './CompletionPopup';

interface ExamScreenProps {
  studentInfo: StudentInfo;
  examData: Question[];
  onFinish: (result: ExamResult) => void;
}

const EXAM_TIME = 8 * 60; // 8 minutes in seconds

export function ExamScreen({ studentInfo, examData, onFinish }: ExamScreenProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(
    new Array(examData.length).fill(null)
  );
  const [timeRemaining, setTimeRemaining] = useState(EXAM_TIME);
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  const [startTime] = useState(Date.now());

  // Timer
  useEffect(() => {
    if (timeRemaining <= 0) {
      handleFinish();
      return;
    }

    const timer = setInterval(() => {
      setTimeRemaining(t => t - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining]);

  // Check if all questions are answered
  useEffect(() => {
    const allAnswered = answers.every(a => a !== null);
    if (allAnswered && !showCompletionPopup) {
      setShowCompletionPopup(true);
    }
  }, [answers, showCompletionPopup]);

  const handleSubmitAnswer = useCallback((answer: number) => {
    setAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[currentQuestion] = answer;
      return newAnswers;
    });

    // Auto-advance to next unanswered question
    const nextUnanswered = answers.findIndex((a, i) => i > currentQuestion && a === null);
    if (nextUnanswered !== -1) {
      setCurrentQuestion(nextUnanswered);
    } else if (currentQuestion < examData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  }, [currentQuestion, answers, examData.length]);

  const handleNavigate = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    } else if (direction === 'next' && currentQuestion < examData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handleFinish = useCallback(() => {
    const timeUsed = Math.round((Date.now() - startTime) / 1000);
    const correctCount = answers.filter(
      (a, i) => a !== null && a === examData[i].correct
    ).length;

    const result: ExamResult = {
      studentInfo,
      totalQuestions: examData.length,
      totalAnswered: answers.filter(a => a !== null).length,
      correctCount,
      timeUsed,
      answers,
      createdAt: new Date(),
    };

    onFinish(result);
  }, [startTime, answers, examData, studentInfo, onFinish]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted p-4">
      <div className="max-w-7xl mx-auto h-[calc(100vh-2rem)]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-full">
          {/* Left Panel - Question Grid */}
          <div className="lg:col-span-3 order-2 lg:order-1">
            <QuestionGrid
              totalQuestions={examData.length}
              currentQuestion={currentQuestion}
              answers={answers}
              onSelectQuestion={setCurrentQuestion}
            />
          </div>

          {/* Center Panel - Question Display */}
          <div className="lg:col-span-6 order-1 lg:order-2">
            <QuestionDisplay
              question={examData[currentQuestion]}
              currentIndex={currentQuestion}
              totalQuestions={examData.length}
              currentAnswer={answers[currentQuestion]}
              onSubmitAnswer={handleSubmitAnswer}
              onNavigate={handleNavigate}
            />
          </div>

          {/* Right Panel - Timer & Info */}
          <div className="lg:col-span-3 order-3">
            <TimerPanel
              studentInfo={studentInfo}
              timeRemaining={timeRemaining}
              answeredCount={answers.filter(a => a !== null).length}
              totalQuestions={examData.length}
              onFinish={handleFinish}
            />
          </div>
        </div>
      </div>

      {/* Completion Popup */}
      {showCompletionPopup && (
        <CompletionPopup
          onContinue={() => setShowCompletionPopup(false)}
          onFinish={handleFinish}
          totalQuestions={examData.length}
        />
      )}
    </div>
  );
}
