import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Question } from '@/types/exam';
import { Send, ChevronLeft, ChevronRight } from 'lucide-react';

interface QuestionDisplayProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  currentAnswer: number | null;
  onSubmitAnswer: (answer: number) => void;
  onNavigate: (direction: 'prev' | 'next') => void;
}

export function QuestionDisplay({ 
  question, 
  currentIndex, 
  totalQuestions,
  currentAnswer,
  onSubmitAnswer,
  onNavigate
}: QuestionDisplayProps) {
  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setInputValue(currentAnswer !== null ? String(currentAnswer) : '');
    inputRef.current?.focus();
  }, [currentIndex, currentAnswer]);

  const handleSubmit = () => {
    const answer = parseInt(inputValue, 10);
    if (!isNaN(answer)) {
      onSubmitAnswer(answer);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    } else if (e.key === 'ArrowLeft') {
      onNavigate('prev');
    } else if (e.key === 'ArrowRight') {
      onNavigate('next');
    }
  };

  return (
    <div className="bg-card rounded-2xl shadow-card p-6 border border-border h-full flex flex-col">
      {/* Question Number */}
      <div className="text-center mb-6">
        <span className="text-lg font-bold text-muted-foreground">
          Câu <span className="text-3xl text-primary">{question.globalNum}</span> / {totalQuestions}
        </span>
      </div>

      {/* Operands Display */}
      <div className="flex-1 flex items-center justify-center">
        <div className="bg-muted rounded-2xl p-8 min-w-[200px]">
          <div className="flex flex-col items-end space-y-2">
            {question.operands.map((op, idx) => (
              <div 
                key={idx} 
                className="text-5xl md:text-6xl font-black tabular-nums text-foreground"
              >
                {op < 0 ? (
                  <span>-{Math.abs(op)}</span>
                ) : (
                  <span>{op}</span>
                )}
              </div>
            ))}
            <div className="w-full h-1 bg-foreground rounded my-2" />
            <div className="text-4xl md:text-5xl font-black text-primary">?</div>
          </div>
        </div>
      </div>

      {/* Answer Input */}
      <div className="mt-6 space-y-4">
        <div className="flex gap-3">
          <Input
            ref={inputRef}
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Nhập đáp án"
            className="h-14 text-2xl font-bold text-center rounded-xl border-2"
          />
          <Button 
            variant="success" 
            size="icon" 
            className="h-14 w-14"
            onClick={handleSubmit}
          >
            <Send className="w-6 h-6" />
          </Button>
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => onNavigate('prev')}
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="w-5 h-5 mr-1" />
            Câu trước
          </Button>
          <Button
            variant="outline"
            onClick={() => onNavigate('next')}
            disabled={currentIndex === totalQuestions - 1}
          >
            Câu sau
            <ChevronRight className="w-5 h-5 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
}
