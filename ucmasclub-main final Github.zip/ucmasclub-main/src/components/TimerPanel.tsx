import { Button } from '@/components/ui/button';
import { StudentInfo } from '@/types/exam';
import { formatTime } from '@/utils/examGenerator';
import { Clock, Trophy, User, GraduationCap, Hash } from 'lucide-react';
import logo from '@/assets/logo_UCMAS.png';

interface TimerPanelProps {
  studentInfo: StudentInfo;
  timeRemaining: number;
  answeredCount: number;
  totalQuestions: number;
  onFinish: () => void;
}

export function TimerPanel({ 
  studentInfo, 
  timeRemaining, 
  answeredCount,
  totalQuestions,
  onFinish 
}: TimerPanelProps) {
  const isLowTime = timeRemaining <= 60;
  const progress = (answeredCount / totalQuestions) * 100;

  return (
    <div className="bg-card rounded-2xl shadow-card p-6 border border-border h-full flex flex-col">
      {/* Logo */}
      <div className="flex justify-center mb-6">
        <img src={logo} alt="UCMAS" className="h-12 w-auto" />
      </div>

      {/* Timer */}
      <div className={`text-center p-6 rounded-2xl mb-6 ${isLowTime ? 'gradient-secondary animate-pulse-soft' : 'gradient-primary'}`}>
        <div className="flex items-center justify-center gap-2 mb-2">
          <Clock className="w-6 h-6 text-primary-foreground" />
          <span className="text-primary-foreground font-bold">Thời gian</span>
        </div>
        <div className="text-5xl font-black text-primary-foreground tabular-nums">
          {formatTime(timeRemaining)}
        </div>
        {isLowTime && (
          <p className="text-primary-foreground/80 text-sm mt-2">
            Sắp hết giờ!
          </p>
        )}
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-sm font-semibold text-muted-foreground">Tiến độ</span>
          <span className="text-sm font-bold text-primary">{answeredCount}/{totalQuestions}</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full gradient-success transition-all duration-300 rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Student Info */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <User className="w-5 h-5 text-primary" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground">Thí sinh</p>
            <p className="font-bold text-foreground truncate">{studentInfo.name}</p>
          </div>
        </div>

        {studentInfo.code && (
          <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
            <Hash className="w-5 h-5 text-primary" />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Mã học sinh</p>
              <p className="font-bold text-foreground">{studentInfo.code}</p>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <GraduationCap className="w-5 h-5 text-primary" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Cấp độ</p>
            <p className="font-bold text-foreground">Cấp {studentInfo.level}</p>
          </div>
        </div>
      </div>

      {/* Finish Button */}
      <Button 
        variant="secondary" 
        size="lg" 
        className="w-full mt-auto"
        onClick={onFinish}
      >
        <Trophy className="w-5 h-5" />
        Hoàn thành bài thi
      </Button>
    </div>
  );
}