import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Question } from '@/types/exam';
import { Send, Play, Timer } from 'lucide-react';

interface FlashQuestionDisplayProps {
  question: Question;
  currentIndex: number;
  totalQuestions: number;
  questionState: 'waiting' | 'countdown' | 'flashing' | 'answering' | 'completed';
  countdownValue: number;
  flashIndex: number;
  answerTimeRemaining: number;
  hasViewed: boolean;
  onStartFlash: () => void;
  onSubmitAnswer: (answer: number) => void;
}

export function FlashQuestionDisplay({ 
  question, 
  currentIndex, 
  totalQuestions,
  questionState,
  countdownValue,
  flashIndex,
  answerTimeRemaining,
  hasViewed,
  onStartFlash,
  onSubmitAnswer,
}: FlashQuestionDisplayProps) {
  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setInputValue('');
    if (questionState === 'answering') {
      inputRef.current?.focus();
    }
  }, [currentIndex, questionState]);

  const handleSubmit = () => {
    const answer = parseInt(inputValue, 10);
    if (!isNaN(answer)) {
      onSubmitAnswer(answer);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  // Get display value for flash
  const getFlashDisplay = () => {
    if (flashIndex < 0) return null;
    if (flashIndex >= question.operands.length) return '=';
    
    const op = question.operands[flashIndex];
    // For addition: no sign, for subtraction: show minus sign
    if (op < 0) {
      return `-${Math.abs(op)}`;
    }
    return `${op}`;
  };

  return (
    <div className="bg-card rounded-2xl shadow-card p-6 border border-border h-full flex flex-col">
      {/* Question Number */}
      <div className="text-center mb-6">
        <span className="text-lg font-bold text-muted-foreground">
          Câu <span className="text-3xl text-green-500">{question.globalNum}</span> / {totalQuestions}
        </span>
      </div>

      {/* Main Display Area */}
      <div className="flex-1 flex items-center justify-center">
        {questionState === 'waiting' && (
          <div className="text-center">
            {hasViewed ? (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-muted flex items-center justify-center">
                  <Timer className="w-10 h-10 text-muted-foreground" />
                </div>
                <p className="text-lg font-medium text-muted-foreground">
                  Đã xem câu này
                </p>
              </div>
            ) : (
              <Button
                onClick={onStartFlash}
                className="h-24 w-24 rounded-full bg-green-500 hover:bg-green-600 transition-all hover:scale-110"
              >
                <Play className="w-12 h-12 text-white" />
              </Button>
            )}
            {!hasViewed && (
              <p className="mt-4 text-muted-foreground font-medium">
                Nhấn để bắt đầu
              </p>
            )}
          </div>
        )}

        {questionState === 'countdown' && (
          <div className="text-center animate-pulse">
            <div className="text-9xl font-black text-green-500">
              {countdownValue}
            </div>
            <p className="mt-4 text-xl text-muted-foreground font-bold">Chuẩn bị...</p>
          </div>
        )}

        {questionState === 'flashing' && (
          <div className="text-center">
            <div className="bg-white rounded-3xl p-12 min-w-[250px] shadow-lg">
              <div className="text-8xl md:text-9xl font-black text-primary tabular-nums animate-flash">
                {getFlashDisplay()}
              </div>
            </div>
          </div>
        )}

        {questionState === 'answering' && (
          <div className="w-full max-w-sm space-y-6">
            {/* Show "=" sign */}
            <div className="text-center mb-4">
              <div className="bg-white rounded-3xl p-8 inline-block shadow-lg">
                <div className="text-7xl font-black text-primary">=</div>
              </div>
            </div>

            {/* Timer */}
            <div className="text-center">
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full font-bold text-lg ${
                answerTimeRemaining <= 3 ? 'bg-destructive/20 text-destructive animate-pulse' : 'bg-green-500/20 text-green-600'
              }`}>
                <Timer className="w-5 h-5" />
                {answerTimeRemaining}s
              </div>
            </div>

            {/* Answer Input */}
            <div className="space-y-4">
              <Input
                ref={inputRef}
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Nhập đáp án"
                className="h-16 text-3xl font-bold text-center rounded-xl border-2"
                autoFocus
              />
              <Button 
                variant="success" 
                className="w-full h-14 text-lg font-bold"
                onClick={handleSubmit}
                disabled={!inputValue}
              >
                <Send className="w-5 h-5 mr-2" />
                Gửi đáp án
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}