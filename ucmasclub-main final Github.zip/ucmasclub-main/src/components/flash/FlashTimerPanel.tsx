import { Button } from '@/components/ui/button';
import { StudentInfo } from '@/types/exam';
import { CheckCircle, User, Layers, Zap, GraduationCap, Hash } from 'lucide-react';

interface FlashTimerPanelProps {
  studentInfo: StudentInfo;
  currentQuestion: number;
  totalQuestions: number;
  answers: (number | null)[];
  hasViewed: boolean[];
  onNavigate: (index: number) => void;
  onFinish: () => void;
}

export function FlashTimerPanel({ 
  studentInfo, 
  currentQuestion,
  totalQuestions,
  answers,
  hasViewed,
  onNavigate,
  onFinish
}: FlashTimerPanelProps) {
  const answeredCount = answers.filter(a => a !== null).length;
  const progressPercent = (answeredCount / totalQuestions) * 100;

  return (
    <div className="space-y-4">
      {/* Student Info */}
      <div className="bg-card rounded-2xl shadow-card p-4 border border-border space-y-3">
        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <User className="w-5 h-5 text-green-500" />
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground">Thí sinh</p>
            <p className="font-bold text-foreground truncate">{studentInfo.name}</p>
          </div>
        </div>

        {studentInfo.code && (
          <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
            <Hash className="w-5 h-5 text-green-500" />
            <div className="flex-1">
              <p className="text-xs text-muted-foreground">Mã học sinh</p>
              <p className="font-bold text-foreground">{studentInfo.code}</p>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <GraduationCap className="w-5 h-5 text-green-500" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Cấp độ</p>
            <p className="font-bold text-foreground">Cấp {studentInfo.level}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-muted rounded-xl">
          <Zap className="w-5 h-5 text-green-500" />
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Tốc độ hiển thị</p>
            <p className="font-bold text-foreground">{studentInfo.displaySpeed}s</p>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="bg-card rounded-2xl shadow-card p-4 border border-border">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold text-foreground">Tiến độ</span>
          <span className="text-sm font-bold text-green-500">{answeredCount}/{totalQuestions}</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden">
          <div 
            className="h-full bg-green-500 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Question Grid - Compact */}
      <div className="bg-card rounded-2xl shadow-card p-4 border border-border">
        <div className="flex items-center gap-2 mb-3">
          <Layers className="w-4 h-4 text-green-500" />
          <span className="text-sm font-bold text-foreground">Câu hỏi</span>
        </div>
        <div className="grid grid-cols-6 gap-1.5 max-h-48 overflow-y-auto">
          {Array.from({ length: totalQuestions }, (_, i) => {
            const isAnswered = answers[i] !== null;
            const isViewed = hasViewed[i];
            const isCurrent = i === currentQuestion;
            
            let bgClass = 'bg-muted text-muted-foreground';
            if (isAnswered) bgClass = 'gradient-success text-white';
            else if (isViewed) bgClass = 'bg-muted text-muted-foreground opacity-50';
            if (isCurrent) bgClass = 'bg-green-500 text-white ring-2 ring-green-500';
            
            return (
              <button
                key={i}
                onClick={() => onNavigate(i)}
                disabled={isViewed || isAnswered}
                className={`
                  aspect-square rounded-lg text-xs font-bold
                  ${bgClass}
                  ${!isViewed && !isAnswered && !isCurrent ? 'hover:bg-green-500/20 cursor-pointer' : ''}
                  ${isViewed || isAnswered ? 'cursor-not-allowed' : ''}
                  transition-all
                `}
              >
                {i + 1}
              </button>
            );
          })}
        </div>
      </div>

      {/* Finish Button */}
      <Button
        onClick={onFinish}
        className="w-full h-12 text-base font-bold gradient-success hover:opacity-90"
      >
        <CheckCircle className="w-5 h-5 mr-2" />
        Hoàn thành
      </Button>
    </div>
  );
}