import { useState, useEffect, useCallback, useRef } from 'react';
import { Question, StudentInfo, ExamResult } from '@/types/exam';
import { FlashQuestionDisplay } from './FlashQuestionDisplay';
import { FlashTimerPanel } from './FlashTimerPanel';
import { CompletionPopup } from '@/components/CompletionPopup';

interface FlashExamScreenProps {
  studentInfo: StudentInfo;
  examData: Question[];
  onFinish: (result: ExamResult) => void;
}

const ANSWER_TIME = 10; // 10 seconds to answer

type QuestionState = 'waiting' | 'countdown' | 'flashing' | 'answering' | 'completed';

export function FlashExamScreen({ studentInfo, examData, onFinish }: FlashExamScreenProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(
    new Array(examData.length).fill(null)
  );
  const [questionState, setQuestionState] = useState<QuestionState>('waiting');
  const [answerTimeRemaining, setAnswerTimeRemaining] = useState(ANSWER_TIME);
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  const [startTime] = useState(Date.now());
  const [hasViewed, setHasViewed] = useState<boolean[]>(
    new Array(examData.length).fill(false)
  );
  const [countdownValue, setCountdownValue] = useState(3);
  const [flashIndex, setFlashIndex] = useState(-1);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const displaySpeedMs = (studentInfo.displaySpeed || 1) * 1000;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  // Answer timer countdown
  useEffect(() => {
    if (questionState === 'answering') {
      timerRef.current = setInterval(() => {
        setAnswerTimeRemaining(prev => {
          if (prev <= 1) {
            handleTimeUp();
            return ANSWER_TIME;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [questionState, currentQuestion]);

  const handleTimeUp = useCallback(() => {
    if (currentQuestion < examData.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
      setFlashIndex(-1);
    } else {
      checkCompletion();
    }
  }, [currentQuestion, examData.length]);

  const checkCompletion = useCallback(() => {
    const allAnswered = answers.every(a => a !== null);
    if (allAnswered) {
      setShowCompletionPopup(true);
    } else {
      const firstUnanswered = answers.findIndex(a => a === null);
      if (firstUnanswered !== -1 && !hasViewed[firstUnanswered]) {
        setCurrentQuestion(firstUnanswered);
        setQuestionState('waiting');
      } else {
        setShowCompletionPopup(true);
      }
    }
  }, [answers, hasViewed]);

  const handleStartFlash = useCallback(() => {
    if (hasViewed[currentQuestion]) return;
    
    // Mark as viewed
    setHasViewed(prev => {
      const newViewed = [...prev];
      newViewed[currentQuestion] = true;
      return newViewed;
    });

    // Start countdown 3-2-1
    setQuestionState('countdown');
    setCountdownValue(3);
    
    let count = 3;
    const countdownInterval = setInterval(() => {
      count--;
      if (count > 0) {
        setCountdownValue(count);
      } else {
        clearInterval(countdownInterval);
        startFlashing();
      }
    }, 1000);
  }, [currentQuestion, hasViewed]);

  const startFlashing = useCallback(() => {
    const question = examData[currentQuestion];
    const operands = question.operands;
    
    setQuestionState('flashing');
    setFlashIndex(0);

    let index = 0;
    const flashInterval = setInterval(() => {
      index++;
      if (index < operands.length) {
        setFlashIndex(index);
      } else {
        clearInterval(flashInterval);
        // Show "=" sign and start answering immediately
        setFlashIndex(operands.length); // This will show "="
        setQuestionState('answering');
        setAnswerTimeRemaining(ANSWER_TIME);
      }
    }, displaySpeedMs);
  }, [currentQuestion, examData, displaySpeedMs]);

  const handleSubmitAnswer = useCallback((answer: number) => {
    if (questionState !== 'answering') return;
    
    setAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[currentQuestion] = answer;
      return newAnswers;
    });

    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (currentQuestion < examData.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
      setFlashIndex(-1);
    } else {
      setTimeout(() => {
        checkCompletion();
      }, 100);
    }
  }, [questionState, currentQuestion, examData.length, checkCompletion]);

  const handleNavigate = (index: number) => {
    if (!hasViewed[index] && answers[index] === null) {
      setCurrentQuestion(index);
      setQuestionState('waiting');
      setAnswerTimeRemaining(ANSWER_TIME);
      setFlashIndex(-1);
    }
  };

  const handleFinish = useCallback(() => {
    const timeUsed = Math.round((Date.now() - startTime) / 1000);
    const correctCount = answers.filter(
      (a, i) => a !== null && a === examData[i].correct
    ).length;

    const result: ExamResult = {
      studentInfo,
      totalQuestions: examData.length,
      totalAnswered: answers.filter(a => a !== null).length,
      correctCount,
      timeUsed,
      answers,
      createdAt: new Date(),
      practiceType: 'flash',
    };

    onFinish(result);
  }, [startTime, answers, examData, studentInfo, onFinish]);

  return (
    <div className="min-h-screen bg-primary p-4">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Panel - Question Display */}
          <div className="lg:col-span-2">
            <FlashQuestionDisplay
              question={examData[currentQuestion]}
              currentIndex={currentQuestion}
              totalQuestions={examData.length}
              questionState={questionState}
              countdownValue={countdownValue}
              flashIndex={flashIndex}
              answerTimeRemaining={answerTimeRemaining}
              hasViewed={hasViewed[currentQuestion]}
              onStartFlash={handleStartFlash}
              onSubmitAnswer={handleSubmitAnswer}
            />
          </div>

          {/* Right Panel - Timer & Progress */}
          <div className="lg:col-span-1">
            <FlashTimerPanel
              studentInfo={studentInfo}
              currentQuestion={currentQuestion}
              totalQuestions={examData.length}
              answers={answers}
              hasViewed={hasViewed}
              onNavigate={handleNavigate}
              onFinish={() => setShowCompletionPopup(true)}
            />
          </div>
        </div>
      </div>

      {/* Completion Popup */}
      {showCompletionPopup && (
        <CompletionPopup
          onContinue={() => setShowCompletionPopup(false)}
          onFinish={handleFinish}
          totalQuestions={examData.length}
        />
      )}
    </div>
  );
}