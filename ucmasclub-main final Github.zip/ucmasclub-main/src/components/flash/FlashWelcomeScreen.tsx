import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { StudentInfo, LEVELS, ExamSet } from '@/types/exam';
import { ArrowLeft, Zap, Timer, Sparkles, User, GraduationCap, FileText, Shuffle, Hash } from 'lucide-react';
import logo from '@/assets/logo_UCMAS.png';

interface FlashWelcomeScreenProps {
  onStart: (info: StudentInfo) => void;
  onBack: () => void;
}

// Sample exam sets - will be replaced with Supabase data
const sampleExamSets: ExamSet[] = [
  { id: '1', name: 'Đề Flash cơ bản', level: 3, questionCount: 30, createdAt: new Date() },
  { id: '2', name: 'Đề Flash nâng cao', level: 5, questionCount: 30, createdAt: new Date() },
];

export function FlashWelcomeScreen({ onStart, onBack }: FlashWelcomeScreenProps) {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [level, setLevel] = useState<number>(3);
  const [examSource, setExamSource] = useState<'auto' | 'preset'>('auto');
  const [selectedExamSet, setSelectedExamSet] = useState<string>('');
  const [displaySpeed, setDisplaySpeed] = useState([1]);
  const [errors, setErrors] = useState<{ name?: string }>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrors({ name: 'Vui lòng nhập tên thí sinh' });
      return;
    }

    onStart({
      name: name.trim(),
      code: code.trim() || undefined,
      level,
      examSource,
      examSetId: examSource === 'preset' ? selectedExamSet : undefined,
      displaySpeed: displaySpeed[0],
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-background via-background to-muted">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-green-500/20 animate-float" />
      <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-green-500/10 animate-float stagger-2" />
      
      <div className="w-full max-w-md animate-slide-up">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBack}
          className="mb-4 -ml-2 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Trang chủ
        </Button>

        {/* Logo */}
        <div className="flex justify-center mb-6">
          <img 
            src={logo} 
            alt="UCMAS Logo" 
            className="h-20 w-auto"
          />
        </div>
        
        {/* Card */}
        <div className="bg-card rounded-2xl shadow-card p-8 border border-border">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-green-500 mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-extrabold text-foreground mb-2">
              Luyện Tập <span className="text-white bg-green-500 px-2 py-1 rounded-lg">Flash</span>
            </h1>
            <p className="text-muted-foreground">
              30 câu hỏi • Thẻ số nhanh
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Name Input */}
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2 text-foreground font-semibold">
                <User className="w-4 h-4 text-green-500" />
                Họ và tên <span className="text-secondary">*</span>
              </Label>
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setErrors({});
                }}
                placeholder="Nhập họ tên học sinh"
                className="h-12 rounded-xl border-2 font-medium focus:border-green-500"
                required
              />
              {errors.name && (
                <p className="text-sm text-secondary">{errors.name}</p>
              )}
            </div>

            {/* Student Code */}
            <div className="space-y-2">
              <Label htmlFor="code" className="flex items-center gap-2 text-foreground font-semibold">
                <Hash className="w-4 h-4 text-green-500" />
                Mã học sinh
              </Label>
              <Input
                id="code"
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Nhập mã học sinh (tùy chọn)"
                className="h-12 rounded-xl border-2 font-medium focus:border-green-500"
              />
            </div>

            {/* Level Select */}
            <div className="space-y-2">
              <Label htmlFor="level" className="flex items-center gap-2 text-foreground font-semibold">
                <GraduationCap className="w-4 h-4 text-green-500" />
                Cấp độ
              </Label>
              <Select value={String(level)} onValueChange={(v) => setLevel(Number(v))}>
                <SelectTrigger className="h-12 rounded-xl border-2 font-medium">
                  <SelectValue placeholder="Chọn cấp độ" />
                </SelectTrigger>
                <SelectContent>
                  {LEVELS.map((l) => (
                    <SelectItem key={l.value} value={String(l.value)}>
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Exam Source */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <FileText className="w-4 h-4 text-green-500" />
                Nguồn đề
              </Label>
              <RadioGroup 
                value={examSource} 
                onValueChange={(v) => setExamSource(v as 'auto' | 'preset')}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="auto" id="auto" />
                  <Label htmlFor="auto" className="flex items-center gap-1 cursor-pointer">
                    <Shuffle className="w-4 h-4" />
                    Tự động sinh đề
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="preset" id="preset" />
                  <Label htmlFor="preset" className="flex items-center gap-1 cursor-pointer">
                    <FileText className="w-4 h-4" />
                    Chọn từ kho đề
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Preset Exam Select */}
            {examSource === 'preset' && (
              <div className="space-y-2 animate-slide-up">
                <Label htmlFor="examSet" className="text-sm font-bold text-foreground">
                  Chọn đề
                </Label>
                <Select value={selectedExamSet} onValueChange={setSelectedExamSet}>
                  <SelectTrigger className="h-12 rounded-xl border-2 font-medium border-accent">
                    <SelectValue placeholder="Chọn đề từ kho" />
                  </SelectTrigger>
                  <SelectContent>
                    {sampleExamSets.map((exam) => (
                      <SelectItem key={exam.id} value={exam.id}>
                        {exam.name} (Cấp {exam.level})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Display Speed Slider */}
            <div className="space-y-4">
              <Label className="flex items-center gap-2 text-foreground font-semibold">
                <Timer className="w-4 h-4 text-green-500" />
                Tốc độ hiển thị: <span className="text-green-500 font-bold">{displaySpeed[0]}s</span>
              </Label>
              <div className="px-2">
                <Slider
                  value={displaySpeed}
                  onValueChange={setDisplaySpeed}
                  min={0.25}
                  max={3}
                  step={0.25}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>Nhanh (0.25s)</span>
                  <span>Chậm (3s)</span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              variant="hero"
              size="xl"
              className="w-full mt-6 bg-green-500 hover:bg-green-600"
              disabled={!name.trim() || (examSource === 'preset' && !selectedExamSet)}
            >
              <Sparkles className="w-6 h-6" />
              BẮT ĐẦU LUYỆN TẬP
            </Button>
          </form>
        </div>

        {/* Footer */}
        <p className="text-center text-muted-foreground text-sm mt-6">
          UCMAS Club - Education With A Difference
        </p>
      </div>
    </div>
  );
}